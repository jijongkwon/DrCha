-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a205.p.ssafy.io    Database: drcha
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member_trust`
--

DROP TABLE IF EXISTS `member_trust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_trust` (
  `trust_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `completed_trades` int DEFAULT NULL,
  `current_debt_trades` int DEFAULT NULL,
  `current_late_trades` int DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  PRIMARY KEY (`trust_id`),
  UNIQUE KEY `UK24ttg7lct4sb4sdtju1nj18xr` (`member_id`),
  CONSTRAINT `FKqwr29li9lbi50ggem5x1wfpgt` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_trust`
--

LOCK TABLES `member_trust` WRITE;
/*!40000 ALTER TABLE `member_trust` DISABLE KEYS */;
INSERT INTO `member_trust` VALUES (1,'2024-10-05 16:59:34.000000','2024-10-08 17:01:15.934944',0,1,0,1),(2,'2024-10-05 16:59:34.000000','2024-10-08 17:52:43.953862',0,1,0,2),(3,'2024-10-05 17:59:51.000000','2024-10-05 17:59:51.000000',0,0,0,4),(5,'2024-10-07 14:01:19.000000','2024-10-09 17:17:55.840046',1,1,0,3),(7,'2024-10-07 15:49:50.333832','2024-10-07 15:49:50.333832',0,0,0,10),(8,'2024-10-07 16:28:25.464115','2024-10-07 16:28:25.464000',0,0,0,12),(9,'2024-10-08 15:40:35.000000','2024-10-08 15:41:05.368350',1,0,0,11),(11,'2024-10-08 15:42:15.286403','2024-10-08 15:42:15.286403',0,0,0,13),(12,'2024-10-08 15:48:20.877155','2024-10-08 15:48:20.877155',0,0,0,14);
/*!40000 ALTER TABLE `member_trust` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 12:31:42
