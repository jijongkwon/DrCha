-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a205.p.ssafy.io    Database: drcha
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `modified_at` datetime(6) DEFAULT NULL,
  `avatar_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` bit(1) DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('ADMIN','MEMBER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `UKmbmcqelty0fbrvxp1q58dn57t` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'2024-10-05 16:37:34.771778','2024-10-09 20:03:19.315793','http://k.kakaocdn.net/dn/bfOtfl/btrSnFqoCtE/7keJ9fqlWivgtQDwU5mD21/img_640x640.jpg','blood194@naver.com',_binary '','010-3424-1232','MEMBER','9ae24c2f-838a-4d8c-8820-2416868346a5','김선웅'),(2,'2024-10-05 16:38:02.159632','2024-10-09 20:15:06.891806','http://k.kakaocdn.net/dn/bbIjP6/btsIg3t8gqJ/R6SKQhEQKODWNdiz8tTRiK/img_640x640.jpg','xhi5929@naver.com',_binary '','010-4505-5929','MEMBER','af01a4e8-5fbb-4c72-864d-3793296c3cee','강민서'),(3,'2024-10-05 16:42:28.086570','2024-10-09 20:11:31.795494','http://k.kakaocdn.net/dn/c658VL/btsJmtESLc7/hStbXmrCEdkFm6br3JasNk/img_640x640.jpg','pkl4693@gmail.com',_binary '','010-5787-4648','MEMBER','1d46f06b-a7de-40ae-b453-580f5d082405','박경림'),(4,'2024-10-05 07:53:21.080196','2024-10-09 19:51:43.253046','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','jiwonlee1953@naver.com',_binary '','010-1313-1313','MEMBER','646553e3-50ab-406c-a43b-20cb8886398b','이지원'),(6,'2024-10-06 01:29:30.565726','2024-10-06 01:29:30.565726','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','hyunsoo730@naver.com',_binary '\0',NULL,'MEMBER','d32006ba-d676-432d-a3be-ac31bf490d1f','조현수'),(7,'2024-10-07 12:09:56.688322','2024-10-07 12:10:12.106400','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','ehdrlf0815@naver.com',_binary '','01034344343','MEMBER','881fc674-694f-459c-852b-142d4790210f','임동길'),(8,'2024-10-07 13:02:43.837435','2024-10-07 15:58:38.226855','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','pnlkc@naver.com',_binary '','','MEMBER','7ba77ab9-e01c-4409-8b11-3f4af104defc','최지찬'),(10,'2024-10-07 15:49:50.302621','2024-10-07 15:50:08.697416','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','gus9300@daum.net',_binary '','01012345678','MEMBER','8b0bfa43-a7d0-45cd-beda-7e3530721b46','최소현'),(11,'2024-10-07 15:52:03.102338','2024-10-08 15:27:24.093708','http://k.kakaocdn.net/dn/Sp8Ma/btrL7unPRae/JFij046ZP4jcNrz7wr8Ke1/img_640x640.jpg','help3451@naver.com',_binary '','01037203451','MEMBER','a7d5c15e-b3c9-4837-96a1-fdca06ca7f17','지종권'),(12,'2024-10-07 16:28:25.460194','2024-10-07 16:54:00.869489','http://k.kakaocdn.net/dn/bBHdgc/btsISIg3xKM/xRdsHJtWkRkLck9Tm1ae80/img_640x640.jpg','mark3473@naver.com',_binary '','01040203473','MEMBER','6a31c1e2-abc4-4522-b256-cac9a0e16b54','남동균'),(13,'2024-10-08 15:42:15.248259','2024-10-08 15:42:37.885444','http://k.kakaocdn.net/dn/hedXz/btsDkDmjJrX/zfmt4TE6uof3udqFCEb8D0/img_640x640.jpg','youbj13@naver.com',_binary '','0989890','MEMBER','fa724e4f-3e07-45c7-8ee6-e668c3578d65','유병주'),(14,'2024-10-08 15:48:20.873505','2024-10-08 15:48:20.873505','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','wjddml0702@naver.com',_binary '\0',NULL,'MEMBER','f31f2bfa-2ddc-4211-a999-cf09122179cc','정의');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 12:31:43
