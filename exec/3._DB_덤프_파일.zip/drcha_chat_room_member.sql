-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11a205.p.ssafy.io    Database: drcha
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_room_member`
--

DROP TABLE IF EXISTS `chat_room_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_room_member` (
  `chat_room_member_id` bigint NOT NULL AUTO_INCREMENT,
  `last_read_message_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_read_time` datetime(6) DEFAULT NULL,
  `member_role` enum('CREDITOR','DEBTOR') COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_enabled` bit(1) DEFAULT NULL,
  `unread_count` int DEFAULT NULL,
  `chat_room_id` bigint NOT NULL,
  `member_id` bigint NOT NULL,
  PRIMARY KEY (`chat_room_member_id`),
  KEY `FKo6a9v51aal2574fjb1ldlw4di` (`chat_room_id`),
  KEY `FKq64atn9y4cyjpp4qcrllxi3o5` (`member_id`),
  CONSTRAINT `FKo6a9v51aal2574fjb1ldlw4di` FOREIGN KEY (`chat_room_id`) REFERENCES `chat_room` (`chat_room_id`),
  CONSTRAINT `FKq64atn9y4cyjpp4qcrllxi3o5` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_member`
--

LOCK TABLES `chat_room_member` WRITE;
/*!40000 ALTER TABLE `chat_room_member` DISABLE KEYS */;
INSERT INTO `chat_room_member` VALUES (1,'6704f2dbb748062aee936b7d','2024-10-10 10:55:14.547240','CREDITOR',_binary '',0,1,1),(2,'6702803ced8f317dd21e1c78','2024-10-08 17:12:17.138545','DEBTOR',_binary '',0,1,2),(5,NULL,NULL,'CREDITOR',_binary '',0,3,2),(10,NULL,NULL,'CREDITOR',_binary '',0,8,2),(11,NULL,NULL,'CREDITOR',_binary '',0,9,1),(12,NULL,NULL,'CREDITOR',_binary '',0,10,1),(13,NULL,NULL,'CREDITOR',_binary '',0,11,1),(14,NULL,NULL,'CREDITOR',_binary '',0,12,1),(15,NULL,NULL,'CREDITOR',_binary '',0,13,1),(16,NULL,NULL,'CREDITOR',_binary '',0,14,4),(17,NULL,NULL,'CREDITOR',_binary '',0,15,1),(19,'6704e6cb8848062c7be6c66e','2024-10-10 12:31:29.497163','CREDITOR',_binary '',0,17,4),(20,'6704e6cb8848062c7be6c66e','2024-10-10 10:42:45.263339','DEBTOR',_binary '',0,17,1),(23,NULL,NULL,'CREDITOR',_binary '',0,20,4),(24,NULL,NULL,'CREDITOR',_binary '',0,21,4),(25,NULL,NULL,'CREDITOR',_binary '',0,22,4),(26,NULL,NULL,'CREDITOR',_binary '',0,23,4),(27,NULL,NULL,'CREDITOR',_binary '',0,24,4),(28,NULL,NULL,'CREDITOR',_binary '',0,25,4),(30,'67061b08b748062aee936b84','2024-10-10 09:12:03.958795','CREDITOR',_binary '',0,27,2),(31,'67071be641f3fd1824d90d07','2024-10-10 12:31:37.046100','DEBTOR',_binary '',0,27,4),(35,NULL,NULL,'CREDITOR',_binary '',0,31,4),(36,NULL,NULL,'CREDITOR',_binary '',0,32,4),(37,NULL,NULL,'CREDITOR',_binary '',0,33,4),(38,NULL,NULL,'CREDITOR',_binary '',0,34,1),(39,NULL,NULL,'CREDITOR',_binary '',0,35,4),(40,NULL,NULL,'CREDITOR',_binary '',0,36,1),(41,NULL,NULL,'CREDITOR',_binary '',0,37,4),(43,NULL,NULL,'CREDITOR',_binary '',0,39,7),(44,'67065be5290bdd707a058380','2024-10-10 11:00:38.718101','CREDITOR',_binary '',0,40,3),(46,'67065be5290bdd707a058380','2024-10-10 09:10:57.901263','DEBTOR',_binary '',0,40,2),(48,'67047ea775653061f98f1f67','2024-10-10 09:11:21.617905','CREDITOR',_binary '',0,43,2),(49,'67047ea775653061f98f1f67','2024-10-09 16:57:45.244639','DEBTOR',_binary '',0,43,3),(50,NULL,NULL,'CREDITOR',_binary '',0,44,10),(51,'6704e5388848062c7be6c66d','2024-10-10 11:09:57.420549','CREDITOR',_binary '',0,45,1),(52,'6704e5388848062c7be6c66d','2024-10-08 17:01:48.618702','DEBTOR',_binary '',0,45,3),(53,NULL,NULL,'CREDITOR',_binary '',0,46,8),(55,NULL,NULL,'CREDITOR',_binary '',0,48,12),(56,'6706373f1d0f182a60788385','2024-10-10 11:00:29.836227','CREDITOR',_binary '',0,49,3),(57,'67039683e410640b5e563ced','2024-10-07 17:11:11.376247','DEBTOR',_binary '',2,49,12),(58,NULL,NULL,'CREDITOR',_binary '',0,50,12),(60,NULL,NULL,'CREDITOR',_binary '',0,52,8),(61,NULL,NULL,'CREDITOR',_binary '',0,53,11),(62,NULL,NULL,'CREDITOR',_binary '',0,54,11),(63,NULL,NULL,'CREDITOR',_binary '',0,55,11),(64,NULL,NULL,'CREDITOR',_binary '',0,56,2),(65,NULL,NULL,'DEBTOR',_binary '',0,56,1),(66,'6704ca6bdae60545341c0ce5','2024-10-10 10:15:58.411226','CREDITOR',_binary '',0,57,1),(67,'6704ca6bdae60545341c0ce5','2024-10-08 17:05:18.192521','DEBTOR',_binary '',0,57,2),(68,NULL,NULL,'CREDITOR',_binary '',0,58,2),(69,NULL,NULL,'CREDITOR',_binary '',0,59,2),(70,'6704c596c0bd647ce41c634c','2024-10-08 14:39:53.744375','CREDITOR',_binary '',0,60,8),(71,'6704d0d6383d892b1d40631a','2024-10-09 17:19:00.627754','CREDITOR',_binary '',0,61,11),(72,'6704d0d6383d892b1d40631a','2024-10-09 17:15:19.250089','DEBTOR',_binary '',0,61,3),(73,'6704d170383d892b1d40631c','2024-10-09 14:37:15.243904','CREDITOR',_binary '',0,62,3),(74,NULL,NULL,'DEBTOR',_binary '',0,62,11),(75,NULL,NULL,'CREDITOR',_binary '',0,63,13),(76,NULL,NULL,'CREDITOR',_binary '',0,64,13),(77,NULL,NULL,'CREDITOR',_binary '',0,65,13),(78,NULL,NULL,'CREDITOR',_binary '',0,66,13),(79,NULL,NULL,'CREDITOR',_binary '',0,67,11),(80,NULL,NULL,'CREDITOR',_binary '',0,68,4),(81,NULL,NULL,'CREDITOR',_binary '',0,69,3),(82,NULL,NULL,'CREDITOR',_binary '',0,70,3),(83,NULL,NULL,'CREDITOR',_binary '',0,71,3),(84,NULL,NULL,'CREDITOR',_binary '',0,72,3),(85,NULL,NULL,'CREDITOR',_binary '',0,73,3),(86,NULL,NULL,'CREDITOR',_binary '',0,74,3),(87,NULL,NULL,'CREDITOR',_binary '',0,75,3),(88,NULL,NULL,'CREDITOR',_binary '',0,76,3),(89,NULL,NULL,'CREDITOR',_binary '',0,77,3),(90,NULL,NULL,'CREDITOR',_binary '',0,78,3),(91,NULL,NULL,'CREDITOR',_binary '',0,79,3),(92,NULL,NULL,'CREDITOR',_binary '',0,80,3),(93,NULL,NULL,'CREDITOR',_binary '',0,81,3),(94,NULL,NULL,'CREDITOR',_binary '',0,82,3),(95,NULL,NULL,'CREDITOR',_binary '',0,83,3),(96,NULL,NULL,'CREDITOR',_binary '',0,84,1),(97,NULL,NULL,'CREDITOR',_binary '',0,85,3),(98,NULL,NULL,'CREDITOR',_binary '',0,86,3),(99,NULL,NULL,'CREDITOR',_binary '',0,87,3),(100,NULL,NULL,'CREDITOR',_binary '',0,88,3),(101,NULL,NULL,'CREDITOR',_binary '',0,89,3),(102,NULL,NULL,'CREDITOR',_binary '',0,90,3),(103,NULL,NULL,'CREDITOR',_binary '',0,91,3),(104,NULL,NULL,'CREDITOR',_binary '',0,92,3),(105,NULL,NULL,'CREDITOR',_binary '',0,93,3),(106,NULL,NULL,'CREDITOR',_binary '',0,94,11),(107,NULL,NULL,'CREDITOR',_binary '',0,95,4),(108,NULL,NULL,'CREDITOR',_binary '',0,96,3),(109,NULL,NULL,'CREDITOR',_binary '',0,97,3),(110,NULL,NULL,'CREDITOR',_binary '',0,98,3),(111,NULL,NULL,'CREDITOR',_binary '',0,99,2),(125,NULL,NULL,'DEBTOR',_binary '',0,94,4),(126,NULL,NULL,'CREDITOR',_binary '',7,100,11),(127,'67067ec44f08c074c351ed87','2024-10-09 22:02:24.180844','DEBTOR',_binary '',0,100,4),(128,NULL,NULL,'CREDITOR',_binary '',0,101,2),(129,NULL,NULL,'CREDITOR',_binary '',0,102,4),(130,NULL,NULL,'CREDITOR',_binary '',0,103,11),(131,NULL,NULL,'CREDITOR',_binary '',0,104,11),(132,NULL,NULL,'CREDITOR',_binary '',0,105,11),(133,NULL,NULL,'DEBTOR',_binary '',0,104,4);
/*!40000 ALTER TABLE `chat_room_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 12:31:43
